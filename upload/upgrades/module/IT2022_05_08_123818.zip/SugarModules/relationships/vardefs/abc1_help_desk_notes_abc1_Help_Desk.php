<?php
// created: 2022-05-08 12:38:18
$dictionary["abc1_Help_Desk"]["fields"]["abc1_help_desk_notes"] = array (
  'name' => 'abc1_help_desk_notes',
  'type' => 'link',
  'relationship' => 'abc1_help_desk_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'side' => 'right',
  'vname' => 'LBL_ABC1_HELP_DESK_NOTES_FROM_NOTES_TITLE',
);
